package com.example.lab1.entities;

import android.graphics.Bitmap;

public class Animal {
    public String url_picture;
    public String name;
    public int age;
    public Animal(String url_picture,String name,int age)
    {
        this.url_picture=url_picture;
        this.name=name;
        this.age=age;
    }
}
